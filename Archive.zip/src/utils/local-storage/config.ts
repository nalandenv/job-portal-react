export const SHORTLISTED = "Shortlisted";
export const REJECTED = "Rejected";