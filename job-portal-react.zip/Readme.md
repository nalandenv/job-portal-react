### Running Instruction
Go to terminal and use following command

```
npm install
npm run dev
```

then visit https://localhost:3000

For checking screenshots, navigate to screnshots folder.

Note: We have used no UI framework but custom CSS for application UI.