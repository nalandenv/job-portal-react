import { Listing } from './Listing'

function App() {
  return <Listing />
}

export default App
